	<?php get_header(); ?>
	<?php include_once('precedent.php'); ?>
	<?php include_once('menu.php'); ?>
	<?php include_once('rubrique.php'); ?>
	<div class="progress">
		<div class="bar"></div>
	</div>
	<div class="progress2">
		<div class="bar2"></div>
	</div>
	<div class="blog">
		<div id="test">
		<div class="content">
	            <?php
			    if(have_posts()):
			    while(have_posts()):
			    the_post();    
			    ?>
			<div class="head_blog">
				<img class="image" src="<?php echo the_post_thumbnail_url(); ?>"/>
				<div class="bloc">
					<h2 class="mobb"><?php the_category();?></h2>
					<h1><?php the_title(); ?></h1>
					<h4 class="sous"><?php the_excerpt(); ?></h4>
					<div class="auteur">
						<img src="<?php echo get_avatar_url( get_the_author_meta('ID'));  ?>" alt="" title="" >
						<h4><?php the_author(); ?></h4>
						<p>3 min lecture</p>
					</div>
					<div class="tags">
					    <?php the_tags(' ',' ',' ');?>
					</div>
					<div class="clr"></div>
				</div>
			</div>
			
			<div class="clr"></div>
			<div class="reseau">
				<a href="" class="fb"><span></span></a>
				<a href="" class="tw"><span></span></a>
				<a href="" class="lin"><span></span></a>
			</div>
			<div class="corp_blog">
			    <?php the_content(); endwhile; wp_reset_postdata(); endif;  ?>
		</div>
		</div>
		<!--FIN CONTENT ***************************************************** !-->
		<div class="content">
			<div class="nws nws2">
				<div class="blo">
					<h3>Get the best reads</h3>
					<p>
						Like what you see? Keep in touch and we’ll send more your way.
					</p>
					<form action="" method="post">
						<input type="email" name="newsletter" value="" placeholder="Votre E-Mail" >
						<input type="submit" name="inscrire" value="S'inscrire" >
					</form>
				</div>
				<img src="images/Groupe-de-masques-26.png" alt="" title="newsletter" >
				<div class="clr"></div>
			</div>

			<div class="policy">
				<p>By signing up you are agreeing to our <a href="" target="_blank">Privacy Policy</a></p>
			</div>

			<div class="clr"></div>
			<h4 class="titree">RELATED ARTICLES</h4>
			<div class="clr"></div>
			<div class="triple_article">
			    <?php  $related = get_posts( array( 'category__in' => wp_get_post_categories($post->ID), 'numberposts' => 3, 'post__not_in' => array($post->ID) ) );
			    foreach( $related as $post ) {
                    setup_postdata($post);?>
				<div class="article">
					<a href="<?php the_permalink(); ?>"><img class="image" src="<?php echo the_post_thumbnail_url(); ?>" alt="" title="" ></a>
					<a href=""><h4 class="rubrique webb"><?php the_category(); ?></h4></a>
					<div class="bloc">
						<a href="<?php the_permalink(); ?>">
						<h3><?php the_title(); ?></h3>
						<div class="auteur">
							<img src="<?php echo get_avatar_url( get_the_author_meta('ID'));  ?>" alt="" title="" >
							<h4>PAR <strong class="name"><?php the_author(); ?></strong></h4>
						</div>
						</a>
					</div>
				</div>
				<?php }
                            wp_reset_postdata();?>
				
				<div class="clr"></div>
			</div>

			<div class="clr"></div>
			
			<h4 class="titree">READ NEXT</h4>
			<?php
             $next_post = get_next_post();
            // var_dump($next_post->ID);
             $next_author = get_user_by( 'id', $next_post->post_author );
             //var_dump($next_author->ID);
             $next_category = get_next_post();
             if (!empty( $next_post )): ?>
			<div class="head_blog foot_blog">
			    <a href="<?php echo esc_url( get_permalink( $next_post->ID ) );?>">
				 <?php $image2 = wp_get_attachment_image_src( get_post_thumbnail_id( $next_post->ID ), 'single-post-thumbnail' ); ?>
				<img class="image" src="<?php echo $image2[0]; ?>"/>
				</a>
				<div class="bloc">
				    <?php $postcat = get_the_category($next_post->ID); ?>
					<h2 class="mobb"><?php if ( ! empty( $postcat ) ) {echo esc_html( $postcat[0]->name );} ?></h2>
					<h1><?php echo esc_attr( $next_post->post_title ); ?></h1>
					<h4 class="sous"><?php echo esc_attr($next_post->post_excerpt);?></h4>
					<div class="auteur">
					    <img src="<?php echo get_avatar_url($next_author->ID );  ?>" alt="" title="" ><!--<img src="<?php //echo get_avatar_url($next_athor);  ?>" alt="" title="" >!-->
						<h4><?php echo $next_author->first_name . ' ' . $next_author->last_name;?></h4>
						<p>3 min lecture</p>
					</div>
					<div class="tags">
					    <?php
					    $post_tags = wp_get_post_tags($next_post->ID, array("fields" => "all"));
					    foreach($post_tags as $post_tag) {
                        echo ' '.'<a href="#">'.$post_tag->name.'</a>'; //do something here
                        }
        			    endif;
					    ?>
					</div>
					<div class="clr" style="height: 40px;"></div>
				</div>
			</div>
		</div>
	</div>
	<?php get_footer(); ?>